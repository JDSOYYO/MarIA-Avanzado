document.addEventListener('DOMContentLoaded', () => {
    // Elementos del DOM
    const elements = {
        textInput: document.getElementById('textInput'),
        generateBtn: document.getElementById('generateBtn'),
        copyBtn: document.getElementById('copyBtn'),
        getSelectedBtn: document.getElementById('getSelectedBtn'),
        clearBtn: document.getElementById('clearBtn'),
        statusEl: document.getElementById('status'),
        configToggle: document.getElementById('configToggle'),
        configContent: document.getElementById('configContent'),
        customPrompt: document.getElementById('customPrompt'),
        savePromptBtn: document.getElementById('savePrompt'),
        resetPromptBtn: document.getElementById('resetPrompt'),
        exampleTags: document.querySelectorAll('.example-tag')
    };

    // Estado
    let isGenerating = false;
    let ollamaUrl = null;
    let availableModels = [];

    // Inicialización
    init();

    // ====== FUNCIONES DE INICIALIZACIÓN ======
    
    function init() {
        // Cargar prompt guardado
        const savedPrompt = localStorage.getItem('ollama_prompt');
        if (savedPrompt) {
            elements.customPrompt.value = savedPrompt;
        }
        
        // Cargar modelo preferido
        const savedModel = localStorage.getItem('ollama_model') || 'llama3.2';
        
        // Mostrar estado inicial
        showStatus('Selecciona texto en cualquier página y haz clic en Generar', 'info');
        
        // Intentar obtener texto seleccionado automáticamente
        getSelectedText();
        
        // Configurar event listeners
        setupEventListeners();
        
        // Intentar detectar Ollama al iniciar
        detectOllamaAndModels();
    }

    function setupEventListeners() {
        // 1. Generar respuesta
        elements.generateBtn.addEventListener('click', generateResponse);
        
        // 2. Copiar texto
        elements.copyBtn.addEventListener('click', copyToClipboard);
        
        // 3. Obtener texto seleccionado
        elements.getSelectedBtn.addEventListener('click', getSelectedText);
        
        // 4. Limpiar
        elements.clearBtn.addEventListener('click', () => {
            elements.textInput.value = '';
            showStatus('Texto limpiado', 'info');
        });
        
        // 5. Toggle configuración
        elements.configToggle.addEventListener('click', () => {
            const isVisible = elements.configContent.classList.contains('show');
            elements.configContent.classList.toggle('show', !isVisible);
            elements.configToggle.innerHTML = isVisible ? 
                '⚙️ Configurar Prompt' : 
                '▲ Ocultar Configuración';
        });
        
        // 6. Guardar prompt
        elements.savePromptBtn.addEventListener('click', () => {
            const prompt = elements.customPrompt.value.trim();
            if (prompt) {
                localStorage.setItem('ollama_prompt', prompt);
                showStatus('Prompt guardado correctamente', 'success');
            } else {
                localStorage.removeItem('ollama_prompt');
                showStatus('Prompt restablecido al predeterminado', 'info');
            }
        });
        
        // 7. Resetear prompt
        elements.resetPromptBtn.addEventListener('click', () => {
            elements.customPrompt.value = '';
            localStorage.removeItem('ollama_prompt');
            showStatus('Prompt restablecido al predeterminado', 'info');
        });
        
        // 8. Ejemplos rápidos
        elements.exampleTags.forEach(tag => {
            tag.addEventListener('click', () => {
                const prompt = tag.getAttribute('data-prompt');
                elements.customPrompt.value = prompt;
                showStatus(`Prompt establecido: "${prompt}"`, 'success');
            });
        });
    }

    // ====== DETECCIÓN DE OLLAMA Y MODELOS ======
    
    async function detectOllamaAndModels() {
        showStatus('🔍 Detectando Ollama y modelos disponibles...', 'info');
        
        const possibleUrls = [
            'http://127.0.0.1:11434',
            'http://localhost:11434'
        ];
        
        for (const url of possibleUrls) {
            try {
                console.log(`Probando conexión a: ${url}/api/tags`);
                
                const response = await fetch(`${url}/api/tags`, {
                    method: 'GET',
                    mode: 'cors',
                    headers: {
                        'Accept': 'application/json'
                    },
                    signal: AbortSignal.timeout(3000)
                });
                
                if (response.ok) {
                    const data = await response.json();
                    ollamaUrl = url;
                    
                    // Extraer nombres de modelos disponibles
                    if (data.models && Array.isArray(data.models)) {
                        availableModels = data.models.map(m => m.name);
                        console.log('Modelos disponibles:', availableModels);
                        
                        if (availableModels.length === 0) {
                            showStatus('✅ Ollama encontrado pero NO hay modelos descargados', 'error');
                            showModelHelp();
                        } else {
                            showStatus(`✅ Ollama encontrado. Modelos: ${availableModels.join(', ')}`, 'success');
                        }
                    } else {
                        availableModels = [];
                        showStatus('✅ Ollama encontrado pero no se pudieron listar modelos', 'info');
                    }
                    
                    return true;
                }
            } catch (error) {
                console.log(`❌ Falló ${url}:`, error.message);
                continue;
            }
        }
        
        showStatus('❌ Ollama no encontrado. Ejecuta "ollama serve" en una terminal.', 'error');
        return false;
    }

    function showModelHelp() {
        const helpDiv = document.createElement('div');
        helpDiv.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 5px 30px rgba(0,0,0,0.3);
            z-index: 10000;
            max-width: 500px;
            width: 90%;
        `;
        
        helpDiv.innerHTML = `
            <h3 style="margin-top: 0; color: #f44336;">⚠️ No hay modelos descargados</h3>
            <p>Necesitas descargar al menos un modelo de Ollama:</p>
            
            <div style="background: #f5f5f5; padding: 15px; border-radius: 5px; margin: 10px 0;">
                <strong>📦 Opciones de modelos (ejecuta en terminal):</strong><br><br>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                    <div style="background: white; padding: 10px; border-radius: 5px;">
                        <strong>🚀 Recomendado (rápido):</strong><br>
                        <code style="background: #e0e0e0; padding: 5px; border-radius: 3px; display: block; margin: 5px 0;">
                            ollama pull llama3.2
                        </code>
                    </div>
                    
                    <div style="background: white; padding: 10px; border-radius: 5px;">
                        <strong>🤖 Potente:</strong><br>
                        <code style="background: #e0e0e0; padding: 5px; border-radius: 3px; display: block; margin: 5px 0;">
                            ollama pull llama3.1
                        </code>
                    </div>
                    
                    <div style="background: white; padding: 10px; border-radius: 5px;">
                        <strong>⚡ Ligero:</strong><br>
                        <code style="background: #e0e0e0; padding: 5px; border-radius: 3px; display: block; margin: 5px 0;">
                            ollama pull phi3
                        </code>
                    </div>
                    
                    <div style="background: white; padding: 10px; border-radius: 5px;">
                        <strong>🌐 Multilingüe:</strong><br>
                        <code style="background: #e0e0e0; padding: 5px; border-radius: 3px; display: block; margin: 5px 0;">
                            ollama pull mistral
                        </code>
                    </div>
                </div>
                
                <br>
                <strong>💡 Consejo:</strong> Recomendamos <code>ollama pull llama3.2</code> (3.8 GB, rápido y bueno)
            </div>
            
            <button id="closeHelp" style="
                width: 100%;
                padding: 12px;
                background: #4CAF50;
                color: white;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                margin-top: 10px;
            ">
                Entendido, descargaré un modelo
            </button>
        `;
        
        document.body.appendChild(helpDiv);
        
        document.getElementById('closeHelp').addEventListener('click', () => {
            helpDiv.remove();
        });
        
        // Cerrar al hacer click fuera
        const overlay = document.createElement('div');
        overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            z-index: 9999;
        `;
        
        document.body.appendChild(overlay);
        overlay.addEventListener('click', () => {
            helpDiv.remove();
            overlay.remove();
        });
    }

    // ====== FUNCIONES PRINCIPALES ======
    
    async function generateResponse() {
        if (isGenerating) return;
        
        const text = elements.textInput.value.trim();
        if (!text) {
            showStatus('Por favor, ingresa o selecciona algún texto primero', 'error');
            return;
        }
        
        // Verificar si tenemos URL de Ollama
        if (!ollamaUrl) {
            showStatus('Buscando Ollama...', 'info');
            const detected = await detectOllamaAndModels();
            if (!detected) {
                showStatus('❌ Ollama no encontrado. Ejecuta "ollama serve" en una terminal.', 'error');
                return;
            }
        }
        
        // Verificar si hay modelos disponibles
        if (availableModels.length === 0) {
            showModelHelp();
            return;
        }
        
        isGenerating = true;
        setGeneratingUI(true);
        
        try {
            // Construir prompt
            const prompt = buildPrompt(text);
            
            // Generar respuesta
            showStatus('Generando respuesta con Ollama...', 'info');
            
            // Intentar con diferentes modelos
            const response = await tryWithAvailableModels(prompt);
            
            if (response) {
                // Mostrar respuesta
                elements.textInput.value = response;
                
                // Copiar automáticamente
                await copyToClipboard(response);
                
                showStatus(`✅ Respuesta generada (${response.length} caracteres) y copiada al portapapeles`, 'success');
            }
            
        } catch (error) {
            console.error('Error:', error);
            
            if (error.message.includes('model') && error.message.includes('not found')) {
                showModelHelp();
            } else {
                showStatus(`❌ Error: ${error.message}`, 'error');
            }
        } finally {
            isGenerating = false;
            setGeneratingUI(false);
        }
    }

    async function tryWithAvailableModels(prompt) {
        // Orden de preferencia de modelos
        const preferredModels = [
            'llama3.2',
            'llama3.1',
            'llama3',
            'phi3',
            'mistral',
            'codellama',
            'neural-chat'
        ];
        
        // Filtrar modelos disponibles
        const modelsToTry = preferredModels.filter(model => 
            availableModels.some(available => 
                available.includes(model) || model.includes(available)
            )
        );
        
        // Si no hay coincidencias exactas, usar el primer modelo disponible
        if (modelsToTry.length === 0 && availableModels.length > 0) {
            modelsToTry.push(availableModels[0]);
        }
        
        console.log('Intentando modelos:', modelsToTry);
        
        // Intentar con cada modelo
        let lastError = null;
        
        for (const model of modelsToTry) {
            try {
                showStatus(`Probando con modelo: ${model}...`, 'info');
                
                const response = await callOllamaAPI(prompt, model);
                
                // Guardar modelo exitoso para futuras peticiones
                localStorage.setItem('ollama_model', model);
                
                return response;
                
            } catch (error) {
                console.error(`Error con modelo ${model}:`, error.message);
                lastError = error;
                continue;
            }
        }
        
        throw lastError || new Error('No se pudo generar respuesta con ningún modelo disponible');
    }

    async function getSelectedText() {
        try {
            showStatus('Obteniendo texto seleccionado...', 'info');
            
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            
            if (!tab) {
                showStatus('No se pudo acceder a la pestaña actual', 'error');
                return;
            }
            
            // Ejecutar script para obtener texto seleccionado
            const results = await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                function: () => {
                    // Método 1: Texto seleccionado con ratón
                    const selection = window.getSelection();
                    if (selection && selection.toString().trim().length > 0) {
                        return selection.toString().trim();
                    }
                    
                    // Método 2: Texto en campo activo
                    const activeElement = document.activeElement;
                    if (activeElement) {
                        if (activeElement.tagName === 'TEXTAREA' || activeElement.tagName === 'INPUT') {
                            const text = activeElement.value || '';
                            if (text.trim().length > 0) {
                                return text.trim();
                            }
                        }
                        
                        // Para elementos contenteditable (como WhatsApp Web)
                        if (activeElement.isContentEditable) {
                            const text = activeElement.textContent || activeElement.innerText || '';
                            if (text.trim().length > 0) {
                                return text.trim();
                            }
                        }
                    }
                    
                    // Método 3: Buscar el campo de entrada de WhatsApp
                    const whatsappInput = document.querySelector('div[contenteditable="true"][data-tab]');
                    if (whatsappInput) {
                        const text = whatsappInput.textContent || whatsappInput.innerText || '';
                        if (text.trim().length > 0) {
                            return text.trim();
                        }
                    }
                    
                    return '';
                }
            });
            
            if (results && results[0] && results[0].result) {
                const selectedText = results[0].result;
                if (selectedText && selectedText.trim().length > 0) {
                    elements.textInput.value = selectedText;
                    showStatus(`✅ Texto seleccionado obtenido (${selectedText.length} caracteres)`, 'success');
                } else {
                    showStatus('No hay texto seleccionado en la página actual', 'info');
                }
            }
            
        } catch (error) {
            console.error('Error obteniendo texto:', error);
            showStatus('No se pudo obtener el texto seleccionado', 'error');
        }
    }

    async function copyToClipboard() {
        const text = elements.textInput.value.trim();
        if (!text) {
            showStatus('No hay texto para copiar', 'error');
            return;
        }
        
        try {
            await navigator.clipboard.writeText(text);
            showStatus('✅ Texto copiado al portapapeles', 'success');
        } catch (error) {
            // Fallback para navegadores antiguos
            elements.textInput.select();
            document.execCommand('copy');
            showStatus('✅ Texto copiado al portapapeles', 'success');
        }
    }

    // ====== FUNCIONES DE OLLAMA ======
    
    function buildPrompt(text) {
        let customPrompt = localStorage.getItem('ollama_prompt');
        
        if (!customPrompt || customPrompt.trim() === '') {
            customPrompt = "Responde al siguiente texto de manera apropiada y útil:";
        }
        
        return `${customPrompt}\n\n"""${text}"""\n\nRespuesta:`;
    }

    async function callOllamaAPI(prompt, model) {
        if (!ollamaUrl) {
            throw new Error('URL de Ollama no configurada');
        }
        
        const url = `${ollamaUrl}/api/generate`;
        console.log(`Enviando a ${url} con modelo: ${model}`);
        
        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    model: model,
                    prompt: prompt,
                    stream: false,
                    options: {
                        temperature: 0.7,
                        top_p: 0.9,
                        num_predict: 500
                    }
                })
            });
            
            console.log('Response status:', response.status, response.statusText);
            
            if (!response.ok) {
                let errorMsg = `Error ${response.status}: ${response.statusText}`;
                
                try {
                    const errorText = await response.text();
                    console.error('Error response text:', errorText);
                    
                    // Intentar parsear como JSON
                    try {
                        const errorJson = JSON.parse(errorText);
                        if (errorJson.error) {
                            errorMsg = errorJson.error;
                        }
                    } catch {
                        // Si no es JSON, usar el texto plano
                        if (errorText) {
                            errorMsg = errorText.substring(0, 100);
                        }
                    }
                } catch {
                    // Ignorar errores al leer el cuerpo
                }
                
                throw new Error(errorMsg);
            }
            
            const data = await response.json();
            console.log('Respuesta recibida de Ollama');
            
            if (!data.response) {
                throw new Error('Ollama no devolvió una respuesta');
            }
            
            return data.response.trim();
            
        } catch (error) {
            console.error('Error en callOllamaAPI:', error);
            throw error;
        }
    }

    // ====== FUNCIONES DE UI ======
    
    function setGeneratingUI(generating) {
        elements.generateBtn.disabled = generating;
        
        if (generating) {
            elements.generateBtn.innerHTML = '<div class="loading"></div><span>Generando...</span>';
        } else {
            elements.generateBtn.innerHTML = '<span>🚀 Generar</span>';
        }
    }

    function showStatus(message, type = 'info') {
        elements.statusEl.textContent = message;
        elements.statusEl.className = `status ${type} show`;
        
        // Auto-ocultar mensajes de éxito después de 4 segundos
        if (type === 'success') {
            setTimeout(() => {
                if (elements.statusEl.textContent === message) {
                    elements.statusEl.classList.remove('show');
                }
            }, 4000);
        }
    }
});