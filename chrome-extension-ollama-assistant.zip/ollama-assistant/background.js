// Background script - necesario para permisos
console.log("Ollama Assistant background script cargado");